import numpy as np
import sklearn.datasets
import matplotlib.pyplot as plt
from my_models.nn import MLP
np.random.seed(1)
X, Y = sklearn.datasets.make_moons(n_samples=200, noise=.2)
X, Y = X.T, Y.reshape(1, Y.shape[0])
m = X.shape[1]
dim = X.shape[0]
#print(X.shape)
#print(Y.shape)
'''
plt.figure(figsize=(8, 6))
plt.scatter(X[0, Y[0,:]==0], X[1, Y[0,:]==0], c='r', marker='s', label='negative')
plt.scatter(X[0, Y[0,:]==1], X[1, Y[0,:]==1], c='b', marker='o', label='postive')
plt.legend(prop={"size":15})
plt.show()
'''
#测试
mlp = MLP()
parameters = mlp.nn_model(X, Y, n_h=3, num_iterations=1500, learning_rate=0.2)
#print(parameters)
Y_pred = mlp.predict(X, parameters)
#print(Y_pred)
accuracy = np.mean(Y_pred == Y)
#print(accuracy)
from matplotlib.colors import ListedColormap

x_min, x_max = X[0, :].min() - 0.5, X[0, :].max() + 0.5
y_min, y_max = X[1, :].min() - 0.5, X[1, :].max() + 0.5
step = 0.001
xx, yy = np.meshgrid(np.arange(x_min, x_max, step), np.arange(y_min, y_max, step))
Z = mlp.predict(np.c_[xx.ravel(), yy.ravel()].T, parameters)
Z = Z.reshape(xx.shape)

plt.figure(figsize=(8, 6))

plt.contourf(xx, yy, Z, cmap=plt.cm.Spectral)

# 绘制边界

plt.scatter(X[0, Y[0,:]==0], X[1, Y[0,:]==0], c='g', marker='s', label='negative')

plt.scatter(X[0, Y[0,:]==1], X[1, Y[0,:]==1], c='k', marker='o', label='postive')
plt.title('20203101694 Suncheng')
plt.legend(prop={"size":15})

plt.show()