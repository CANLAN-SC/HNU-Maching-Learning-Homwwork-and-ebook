import numpy as np
import matplotlib.pyplot as plt
import sklearn.datasets
np.random.seed(1)
X, Y = sklearn.datasets.make_moons(n_samples=200, noise=.2)
X, Y = X.T, Y.reshape(1, Y.shape[0])
m = X.shape[1]
dim = X.shape[0]
#print(X.shape)
#print(Y.shape)

plt.figure(figsize=(8, 6))
plt.scatter(X[0, Y[0,:]==0], X[1, Y[0,:]==0], c='r', marker='s', label='negative')
plt.scatter(X[0, Y[0,:]==1], X[1, Y[0,:]==1], c='b', marker='o', label='postive')
plt.legend(prop={"size":15})
plt.show()