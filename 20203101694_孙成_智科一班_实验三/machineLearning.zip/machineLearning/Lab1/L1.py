'''
X = np.linspace (0, 100, 100)
X = np.c_[X, np.ones (100)]
w = np.asarray( [3,2])
Y = X.dot(w)
X= X.astype('float')
Y= Y.astype('float')
X[:,0]+=np.random.normal(size=(X[:, 0].shape))*3
Y = Y.reshape (100,1)
'''
'''
plt.scatter(X[:,0],Y)
plt. plot(np.arange(0, 100).reshape((100,1)),Y,'r')
plt.xlabel('X')
plt.ylabel('Y')
plt.show()
'''
'''
w=np.random.random(size=(2,1))
epoches=100
eta=0.0000001
losses=[]
for _ in range(epoches):
	dw=-2*X.T.dot(Y-X.dot(w))
	w = w - eta * dw
	losses.append((Y-X.dot(w)).T.dot(Y-X.dot(w)).reshape(-1))
print(losses)
'''
'''
plt.scatter (X[:,0],Y)
plt.plot(X[:, 0], X. dot (w),'r')
plt.xlabel('x')
plt.ylabel('Y')
plt.show()
'''
'''
plt.plot(losses)
plt.xlabel('iterations')
plt.ylabel('loss')
plt.show()
'''
'''
w=np.linalg.pinv(X).dot (Y)
plt.scatter (X[:, 0], Y)
plt.plot(X[:, 0], X. dot (w),'r')
plt.plot(np. arange (0, 100).reshape((100, 1)),Y, c='b', linestyle='--')
plt.xlabel ('X')
plt.ylabel ('Y')
plt.show()
'''
'''
t=np.arange(-8, 8, 0.5)
d_t=1/(1+np.exp(-t))
plt.plot (t, d_t)
plt.show()
'''
#!/usr/bin/python
# -*- coding: UTF-8 -*-

import numpy as np
import matplotlib.pyplot as plt

###将根目录添加到sys.path，解决在命令行下执行时找不到模块的问题。
import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

#构造伪分类数据并可视化
from sklearn.datasets import make_classification
from my_models import LogisticRegression
lr = LogisticRegression()
data,target=make_classification(n_samples=100, n_features=2,n_classes=2,n_informative=1,n_redundant=0,n_repeated=0,n_clusters_per_class=1)
lr.fit(data, target)
w1=lr.coef_[0][0]
w2=lr.coef_[0][1]
bias=lr.intercept_[0]
print(wl)
print(w2)
print(bias)
#画决策边界
xl=p.arange(np.min(data),np.max(data),0.1)
x2=-wl/w2*x1-bias/w2
plt.scatter(data[:, 0], data[:, 1], c=target,s=50)
plt.plot(x1 ,x2,T)
plt.show()
#计算F1
f1_score(target,lr.predict( datal))