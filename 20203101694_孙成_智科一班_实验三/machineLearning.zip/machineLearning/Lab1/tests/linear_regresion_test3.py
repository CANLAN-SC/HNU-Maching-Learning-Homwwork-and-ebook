import numpy as np
import matplotlib.pyplot as plt

###Add the root directory to sys.path to solve the problem that the command line cannot find the package
import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)

# 造伪样本
X = np.linspace(0, 100, 100)
X = np.c_[X, np.ones(100)]  #考虑到偏置b
w = np.asarray([3, 2])  #参数
Y = X.dot(w)    
X = X.astype('float')
Y = Y.astype('float')
X[:, 0] += np.random.normal(size=(X[:, 0].shape)) * 3  # 添加0,1高斯噪声

Y = Y.reshape(100, 1)

#与sklearn对比
from sklearn.linear_model import LinearRegression

lr=LinearRegression()
lr.fit(X[:,:-1],Y)
predict=lr.predict(X[:,:-1])
#查看w,b
print('w:',lr.coef_,'b:',lr.intercept_)
#查看标准差
print(np.std(Y-predict))

#可视化结果
plt.scatter(X[:, 0], Y)
plt.plot(X[:, 0], predict, 'r')
plt.plot(np.arange(0,100).reshape((100,1)),Y, c='b', linestyle='--')
plt.show()
