import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#定义函数： 计算欧式距离
def euclDistance (point1,point2) :
	#计算两点point1、point2之间的欧式距离
	distance = np. sqrt (sum (pow (point2-point1,2)) )
	return distance

def initCentroids(dataSet, k):
	# dataSet为数据集
	#k是指用户设定的k个簇
	numSamples,dim = dataSet.shape # numSample：数据集数量；dim： 特征维度
	centroids = np.zeros((k, dim)) #存放质心坐标，初始化k行、 dim列零矩阵
	for i in range(k):
		#index = int(np.random.uniform(0, numSamples)) # 给出一个服从均匀分布的在0~numSamples之间的整数
		index = np.random.randint(0,numSamples) # 给出一个随机分布在0~numSamples之间的整数
		centroids[i, :] = dataSet[index, :] # 第index行作为质心
	return centroids

def kmeans(dataSet, k):
	# dataSet 为数据集
	# k是指用户设定的 k个簇
	numSamples = dataSet.shape[0]
	clusterAssment = np.zeros((numSamples,2)) #clusterAssment 第 1 列存放所属的簇，第 2 列存放与质心的距离
	clusterChanged = True #clusterChanged=False 时迭代更新终止
	## step 1：初始化质心 centroids
	centroids = initCentroids(dataSet, k) # 循环体：是否更新质心
	while clusterChanged:
		clusterChanged = False #关闭更新
		# 对每个样本点
		for i in range(numSamples):
			minDist = 100000.0  # 最小距离
			minIndex = 0  # 最小距离对应的簇
			# step2：找到距离每个样本点最近的质心
			# 对每个质心
			for j in range(k):
				distance = euclDistance(centroids[j, :],dataSet[i,:])  # 计算每个样本点到质心的欧式距离
				if distance < minDist: # 如果距离小小当前最小距离minDist
					minDist = distance #最小距离更新
					minIndex = j  # 样本所属的簇也会更新
				## step3：更新样本所属的簇
			if clusterAssment[i, 0] != minIndex:  # 如当前样本不属于该簇
				clusterChanged = True #聚类操作需要继续
			clusterAssment[i, :] = minIndex, minDist
		# step 4： 更新质心
		# 对每个质心
		for j in range(k):
			pointsInCluster = dataSet[np.nonzero(clusterAssment[:, 0] == j)[0]]
			# pointsInCluster 存储的是当前所有属于簇 j的 dataSet 样本点
			centroids[j, :] = np.mean(pointsInCluster, axis=0) # 更新簇j 的质心
	print("cluster complete!")
	return centroids, clusterAssment

def selectK(dataSet, k_list):
	# dataset为数据集
	# k_list不同k值列表
	distanceK=[]#存储不同k值下每个样本点到质心的平均欧式距离
	for i, k in enumerate(k_list):
		centroids,clusterAssment = kmeans(dataSet,k) #调用kmeans函数
		distance = np.mean(clusterAssment[:,1],axis=0) # clusterAssment所有minDist的平
		distanceK.append(distance)
	#best k =klist[np.argmin（distanceK）]#能够让距离最小的k值
	return distanceK

def showCluster(dataSet, k, centroids, clusterAssment):
	# dataSet为数据集
	#k是指用户设定的k个簇
	# centroids存放质心坐标
	#clusterAssment第1列存放所属的簇，第2列存放与质心的距离
	numSamples,dim = dataSet.shape # numSample：数据集数量； dim：特征维度
	if dim!= 2:
		print("The dimension of data is not 2!")
		return 1
	
	mark= ['or', 'ob', 'og', 'ok', '^r', '+r', 'sr', 'dr', '<r', 'pr']
	if k > len(mark):
		print("K is too large!")
		return 1
	#画所有的样本
	plt.figure()
	for i in range(numSamples):
		markIndex = int(clusterAssment[i, 0])
		plt.plot(dataSet[i, 0], dataSet[i, 1], mark[markIndex])
	mark = ['Dr', 'Db', 'Dg', 'Dk', '^b', '+b', 'sb', 'db', '<b', 'pb']
	#画所有的质心
	for i in range(k):
		plt.plot(centroids[i, 0], centroids[i, 1], mark[i], ms=12.0)
	plt.title('K-means(K={})'.format(k))
	plt.xlabel('x')
	plt.ylabel('y')
	plt.show()

#导入数据集
dataSet = pd.read_csv('/Users/suncheng/PycharmProjects/machineLearning/Lab3/dataSet.csv')
dataSet = dataSet.values #(80,2)
#选择不同的k值对比
k_list = [2, 3, 4, 5, 6]
disK = selectK(dataSet, k_list) #画图
plt.figure()
plt.plot(k_list, disK, 'ro-')
plt.title('Cross-validation on k')
plt.xlabel('K')
plt.ylabel('Mean Euclidean distance')
plt.show()
# 使用K-means算法进行聚类
k = 4
centroids, clusterAssment = kmeans(dataSet, k) #作图可视化kmeans聚类效果
showCluster(dataSet, k, centroids, clusterAssment)
