import numpy as np
class MLP(object):
	
	def initialize_parameters(self, n_x, n_h, n_y):
		np.random.seed(0)
		# 设置随机种子
		# 参数初始化
		W1 = np.random.randn(n_h, n_x)
		b1 = np.zeros((n_h, 1))
		W2 = np.random.randn(n_y, n_h)
		b2 = np.zeros((n_y, 1))
		parameters = {
			'W1': W1,
			'b1': b1,
			'W2': W2,
			'b2': b2
		}
		return parameters
	
	def sigmoid(self, z):
		a = 1 / (1 + np.exp(-z))
		return a
	
	def forward_propagation(self, X, parameters):
		W1 = parameters['W1']
		b1 = parameters['b1']
		W2 = parameters['W2']
		b2 = parameters['b2']
		# 输入层 一> 隐藏层
		Z1 = np.dot(W1, X) + b1
		A1 = np.tanh(Z1)
		# 隐藏层 一> 输出层
		Z2 = np.dot(W2, A1) + b2
		A2 = self.sigmoid(Z2)
		cache = {
			'Z1': Z1,
			'A1': A1,
			'Z2': Z2,
			'A2': A2
		}
		return A2, cache
	
	def compute_loss(self, A2, Y):
		m = Y.shape[1]
		cross_entropy = -(Y * np.log(A2) + (1 - Y) * np.log(1 - A2))
		cost = 1.0 / m * np.sum(cross_entropy)
		return cost
	
	def back_propagation(self, X, Y, parameters, cache):
		m = X.shape[1]
		# 神经网络参数
		W1 = parameters['W1']
		b1 = parameters['b1']
		W2 = parameters['W2']
		b2 = parameters['b2']
		# 中间变量
		Z1 = cache['Z1']
		A1 = cache['A1']
		Z2 = cache['Z2']
		A2 = cache['A2']
		# 计算梯度
		dZ2 = A2 - Y
		dW2 = 1.0 / m * np.dot(dZ2, A1.T)
		db2 = 1.0 / m * np.sum(dZ2, axis=1, keepdims=True)
		dZ1 = np.dot(W2.T, dZ2) * (1 - np.power(A1, 2))
		dW1 = 1.0 / m * np.dot(dZ1, X.T)
		db1 = 1.0 / m * np.sum(dZ1, axis=1, keepdims=True)
		grads = {
			'dW1': dW1,
			'db1': db1,
			'dW2': dW2,
			'db2': db2
		}
		return grads
	
	def update_parameters(self, parameters, grads, learning_rate=0.1):
		# 神经网络参数
		W1 = parameters['W1']
		b1 = parameters['b1']
		W2 = parameters['W2']
		b2 = parameters['b2']
		# 神经网络参数梯度
		dW1 = grads['dW1']
		db1 = grads['db1']
		dW2 = grads['dW2']
		db2 = grads['db2']
		# 梯度下降算法
		W1 = W1 - learning_rate * dW1
		b1 = b1 - learning_rate * db1
		W2 = W2 - learning_rate * dW2
		b2 = b2 - learning_rate * db2
		parameters = {
			'W1': W1,
			'b1': b1,
			'W2': W2,
			'b2': b2
		}
		return parameters
	
	def nn_model(self, X, Y, n_h=3, num_iterations=200, learning_rate=0.1):
		# 定义网络
		n_x = X.shape[0]
		n_y = 1
		# 参数初始化
		parameters = self.initialize_parameters(n_x, n_h, n_y)  # 迭代训练
		for i in range(num_iterations):
			# 正向传播
			A2, cache = self.forward_propagation(X, parameters)
			
			cost = self.compute_loss(A2, Y)
			grads = self.back_propagation(X, Y, parameters, cache)
			# 更新参数
			parameters = self.update_parameters(parameters, grads, learning_rate)
			# print
			if (i + 1) % 20 == 0:
				print('Iteration: % d, cost = % f' % (i + 1, cost))
		return parameters
	
	def predict(self, X, parameters):
		# 神经网络参数
		W1 = parameters['W1']
		b1 = parameters['b1']
		W2 = parameters['W2']
		b2 = parameters['b2']
		# 输入层->隐藏层
		Z1 = np.dot(W1, X) + b1
		A1 = np.tanh(Z1)
		# 隐藏层->输出层
		Z2 = np.dot(W2, A1) + b2
		A2 = self.sigmoid(Z2)
		# 预测标签
		Y_pred = np.zeros((1, X.shape[1]))  # 初始化Y_pred
		Y_pred[A2 > 0.5] = 1  # Y_ hat 大于0.5 的预测为正类
		return Y_pred