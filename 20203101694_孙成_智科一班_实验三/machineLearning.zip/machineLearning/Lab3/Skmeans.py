import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans

plt.rcParams['font.sans-serif']= ['Heiti TC']
# X 为样本特征，Y 为样本簇类别， 共 1000 个样本，每个样本 4 个特征，共 4 个簇，簇中心 在[-1,-1], [0,0],[1,1], [2,2]， 簇方差分别为[0.4, 0.2, 0.2]
X, y = make_blobs(n_samples=1000, n_features=2, centers=[[-1, -1], [0, 0], [1, 1], [2, 2]],
					cluster_std=[0.4, 0.2, 0.2, 0.2],
					random_state=9)
plt.scatter(X[:, 0], X[:, 1], marker='o')
plt.title('数据集展示')
plt.show()
print(X)

#k=2

y_pred = KMeans(n_clusters=2, random_state=9).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred)
plt.title('k=2')
plt.show()

# k=3
y_pred = KMeans(n_clusters=3, random_state=9).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred)
plt.title('k=3')
plt.show()

# k=4
y_pred = KMeans(n_clusters=4, random_state=9).fit_predict(X)
plt.scatter(X[:, 0], X[:, 1], c=y_pred)
plt.title('k=4')
plt.show()